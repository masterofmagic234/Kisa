#!/usr/bin/env python3
from pathlib import Path
from collections import Counter
import csv, hashlib, json, os, re, runpy, signal, subprocess, sys, time
mode='immediate'
if sys.argv[1:] not in ([], ['kebab'], ['kebab', '--diagnostics']):
 raise SystemExit('Usage: cs2-benchmark.py [kebab [--diagnostics]]')
kebab='kebab' in sys.argv[1:]
diagnostics='--diagnostics' in sys.argv[1:]
test_ccx1=kebab and os.environ.get('CS2_TEST_CCX1')=='1'
test_render12=kebab and os.environ.get('CS2_TEST_RENDER12')=='1'
test_main2=kebab and os.environ.get('CS2_TEST_MAIN2')=='1'
test_main_pair=kebab and os.environ.get('CS2_TEST_MAIN_PAIR')=='1'
test_wake_trace=kebab and os.environ.get('CS2_TEST_WAKE_TRACE')=='1'
test_peak_trace=os.environ.get('CS2_TEST_PEAK_TRACE')=='1'
test_present_trace=os.environ.get('CS2_TEST_PRESENT_TRACE')=='1'
test_memory_trace=os.environ.get('CS2_TEST_MEMORY_TRACE')=='1'
narrow_peak_trace=test_peak_trace and os.environ.get('CS2_TEST_PEAK_NARROW')=='1'
phase_counts=narrow_peak_trace and os.environ.get('CS2_TEST_ENGINE_PHASE_COUNTS')=='1'
matrix=os.environ.get('CS2_TEST_MATRIX')=='1'
measure_locked_cpu=matrix and os.environ.get('CS2_TEST_REQUIRE_LOCK')=='1'
measure_game_scope=os.environ.get('CS2_TEST_GAME_SCOPE')=='1'
assert not test_memory_trace or (measure_game_scope and not (test_wake_trace or test_peak_trace or test_present_trace))
replay_prime=os.environ.get('CS2_TEST_REPLAY_PRIME')
assert replay_prime in (None,'paused','played') and (replay_prime is None or measure_game_scope)
render_cpu=12 if test_ccx1 or test_render12 else 6
main_cpu=2 if test_main2 else 14
test_pool={8,9,10,11} if test_ccx1 else set(range(12)) if test_render12 else None
seek_tick=39736 if kebab else 43100
slot=6 if kebab else 9
variant='kebab-reference-replay' if kebab else 'nuke-138-replay'
hfr1_gfx=os.environ.get('CS2_TEST_HFR1_GFX')=='1'
assert not hfr1_gfx or (not kebab and not any((diagnostics,test_peak_trace,test_present_trace,test_memory_trace,matrix)))
if hfr1_gfx:
 seek_tick=int(os.environ.get('CS2_TEST_HFR1_SEEK','10048'))
 variant='nuke-hfr1-gfx'
kernel='7.2.3-ps5-hfr1' if hfr1_gfx else '7.2.3-ps5-m2-1850'
assert os.uname().release==kernel,'Boot the requested trial kernel first'
if subprocess.run(['pgrep','-x','steam'],stdout=subprocess.DEVNULL).returncode:
 raise SystemExit('Start Steam before running the CS2 benchmark.')
from PIL import ImageGrab

def active_clock_invocation():
 active, invocation = subprocess.check_output(['systemctl','show','ps5-clock-trial.service',
     '-p','ActiveState','-p','InvocationID','--value'],text=True,timeout=3).splitlines()
 if active!='active' or not invocation.strip('0'):
  raise RuntimeError(f'Clock protection is not ready ({active})')
 return invocation

clock_invocation=active_clock_invocation() if measure_locked_cpu else None

def require_same_clock():
 if clock_invocation is not None and active_clock_invocation()!=clock_invocation:
  raise RuntimeError('Clock protection changed during replay')

def recent_present(path, now):
 with path.open(newline='') as stream:
  rows=[(float(row['mono']), int(row['mode'])) for row in csv.DictReader(stream)
        if row['kind']=='0' and row['mode'] and now-.3<=float(row['mono'])<=now]
 modes=Counter(mode for _,mode in rows)
 newest_age=now-rows[-1][0] if rows else None
 return {'checked_mono':now,'modes':dict(modes),'newest_age_s':newest_age,
         'reject_copy':len(rows)>=20 and set(modes)=={0} and newest_age<=.07}

base=Path(__file__).resolve().parents[2]
outputs=base/'outputs'
x11=runpy.run_path(str(base/'work/cs2-x11-compositor.py'))
compositor_state=x11['compositor_state']
window_manager,_=compositor_state()
private_icd=expected_library=None
ib160_policy=os.environ.get('CS2_TEST_IB160_POLICY')
assert ib160_policy is None or (ib160_policy in ('0','1') and measure_locked_cpu and os.environ.get('CS2_TEST_PRIVATE_ICD'))
if selected:=os.environ.get('CS2_TEST_PRIVATE_ICD'):
 private_icd=Path(selected).resolve(strict=True)
 private_root=(Path.home()/'.cache/cs2-mesa2608-builds').resolve()
 known={}
 for status,labels in (
  ('cs2-mesa2608-noalias-build-status.json',('A2-O2-noalias','C2-O2-LTO-noalias')),
  ('cs2-mesa2608-mr44898-build-status.json',('D3-O2-fastpath-noalias','E3-O2-boundstages-noalias')),
 ):
  builds=json.loads((outputs/status).read_text())['variants']
  for label in labels:
   record=builds[label]
   known[Path(record['icd']).resolve()]=record
 library_record=known.get(private_icd)
 if ib160_policy is not None:
  gate=runpy.run_path(str(base/'work/cs2-radv-ib160-gate.py'))
  library_record=gate['require_pass'](private_icd)
 if library_record is None:
  assert private_icd.parent.parent==private_root and private_icd.parent.name.startswith('upload-floor-')
  library_record=json.loads((private_icd.parent/'status.json').read_text())
  assert library_record['status']=='CPU_BUILD_VERIFIED_GPU_VALIDATION_PENDING'
 expected_sha=library_record.get('sha256') or library_record['library_sha256']
 assert private_icd==Path(library_record['icd']).resolve()
 assert hashlib.sha256(private_icd.read_bytes()).hexdigest()==library_record['icd_sha256']
 expected_library=Path(json.loads(private_icd.read_text())['ICD']['library_path']).resolve(strict=True)
 assert expected_library==Path(library_record['library']).resolve()
 with expected_library.open('rb') as library:
  assert hashlib.file_digest(library,'sha256').hexdigest()==expected_sha
out=outputs/f"cs2-{'kebab' if kebab else 'nuke'}-{kernel.removeprefix('7.2.3-ps5-')}-{int(time.time())}"
out.mkdir()
common=Path.home()/'.steam/debian-installation/steamapps/common'
log=common/'Counter-Strike Global Offensive/game/csgo/console.log'
video,=Path.home().glob('.steam/debian-installation/userdata/*/730/local/cfg/cs2_video.txt')
cfg=video.parent
saved={p:p.read_bytes() for p in [video,cfg/'cs2_user_convars_0_slot0.vcfg',cfg/'cs2_machine_convars.vcfg']}
demo=('replays/match730_003851785353190965676_1755011521_182' if kebab else
      'replays/match730_003852354427767750703_1695226765_421')
steam_cfg,=Path.home().glob('.steam/debian-installation/userdata/*/config/localconfig.vdf')
launch_opts=(outputs/'cs2-steam-system-profile-installed.txt').read_text().strip()
assert launch_opts.replace('"',r'\"') in steam_cfg.read_text()
assert subprocess.run(['pgrep','-x','cs2'],stdout=subprocess.DEVNULL).returncode==1
def write(path,data):
 temporary=path.with_name('.codex-cs2-combined-'+path.name)
 with temporary.open('xb') as f:f.write(data)
 os.chmod(temporary,path.stat().st_mode & 0o777)
 os.replace(temporary,path)
def stop(n,frame):raise InterruptedError(n)
for n in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(n,stop)
def read_from(offset=0):
 with log.open() as f:
  f.seek(offset)
  return f.read()
def await_log(pattern,offset=0,timeout=25):
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  current=read_from(offset)
  if re.search(pattern,current,re.M):return current
  time.sleep(.16)
 raise RuntimeError('Missing replay marker '+pattern)
pid=window=launcher=None
scope_dir=None
try:
 fast=saved[video]
 for key,old,new in [(b'videocfg_fsr_detail',b'0',b'4'),(b'videocfg_dynamic_shadows',b'1',b'0')]:
  pattern=rb'("setting\.'+key+rb'"\s+")['+old+new+rb'](")'
  fast,n=re.subn(pattern,lambda m:m[1]+new+m[2],fast)
  assert n==1,key
 (out/'video-tested.txt').write_bytes(fast)
 if not hfr1_gfx:write(video,fast)
 else:(out/'video-tested.txt').write_bytes(saved[video])
 game=common/'Counter-Strike Global Offensive/game'
 placement=base/'work/cs2-core-placement-ccx1.sh' if test_pool or test_main2 else outputs/'cs2-core-placement.sh'
 vulkan_env=[f'VK_DRIVER_FILES={private_icd}','RADV_PS5_EXPERIMENTAL_COMPUTE=0'] if private_icd else []
 if ib160_policy is not None:
  vulkan_env.append(f'RADV_PS5_GFX_IB_160K={ib160_policy}')
 args=['sh',str(placement),str(common/'SteamLinuxRuntime_sniper/run'),'--','/usr/bin/env',
       'SteamAppId=730','SteamGameId=730',f'MESA_VK_WSI_PRESENT_MODE={mode}',*vulkan_env,str(game/'cs2.sh'),
       '-steam','-insecure','-condebug','-threads','10',
       *([] if hfr1_gfx else ['+cl_draw_only_deathnotices','1','+cl_drawhud_force_deathnotices','-1','+r_player_visibility_mode','0'])]
 if measure_game_scope:
  scope_name=f'cs2-replay-diag-{os.getpid()}.scope'
  args=['systemd-run','--user','--scope','--quiet','--collect',f'--unit={scope_name}',
        '--slice=app.slice','-p','MemoryAccounting=yes','--',*args]
 with (out/'launch.log').open('w') as capture_log:
  launcher=subprocess.Popen(args,stdout=capture_log,stderr=subprocess.STDOUT,start_new_session=True)
 end=time.monotonic()+80
 while time.monotonic()<end:
  p=subprocess.run(['pgrep','-nx','cs2'],capture_output=True,text=True)
  if p.returncode==0:
   proc=Path('/proc',p.stdout.strip())
   pid=int(proc.name)
   argv=(proc/'cmdline').read_bytes().split(b'\0')
   assert argv.count(b'-insecure')==1 and b'-secure' not in argv and b'-condebug' in argv
   assert argv[argv.index(b'-threads')+1]==b'10'
   env=(proc/'environ').read_bytes().split(b'\0')
   assert f'MESA_VK_WSI_PRESENT_MODE={mode}'.encode() in env
   w=x11['active_window']()
   if w is None:
    time.sleep(.35)
    continue
   props=subprocess.run(['xprop','-id',w,'_NET_WM_PID','WM_CLASS'],text=True,capture_output=True,timeout=3)
   state=props.stdout if props.returncode==0 else ''
   if '"cs2"' in state and re.search(r'_NET_WM_PID\(CARDINAL\) = '+str(pid)+r'\b',state):
    window=w
    threads={}
    for t in (proc/'task').iterdir():
     try:threads[int(t.name)]=(t/'comm').read_text().strip()
     except FileNotFoundError:pass
    workers=sum(name.startswith('GlobPool/') for name in threads.values())
    render=[tid for tid,name in threads.items() if name=='VKRenderThread']
    if render and workers==9 and os.sched_getaffinity(pid)=={main_cpu} and os.sched_getaffinity(render[0])=={render_cpu}:
     if test_pool and any(os.sched_getaffinity(tid)!=test_pool for tid in threads
                          if tid not in (pid,render[0])):
      time.sleep(.2)
      continue
     paths=sorted({line.split(maxsplit=5)[-1] for line in (proc/'maps').read_text().splitlines() if 'libvulkan_radeon.so' in line})
     assert len(paths)==1,paths
     if private_icd:
      assert f'VK_DRIVER_FILES={private_icd}'.encode() in env
      assert (proc/'root'/paths[0].lstrip('/')).samefile(expected_library),paths
      if ib160_policy is not None:
       assert f'RADV_PS5_GFX_IB_160K={ib160_policy}'.encode() in env
     else:
      assert '/usr/lib/x86_64-linux-gnu/libvulkan_radeon.so' in paths[0],paths
     if window_manager=='Xfwm4':
      x11['fullscreen_xfwm'](window)
      time.sleep(.4)
      window_state=subprocess.check_output(['xprop','-id',window,'_NET_WM_STATE'],text=True,timeout=3)
      if '_NET_WM_STATE_FULLSCREEN' not in window_state:
       raise RuntimeError('Xfwm4 did not enter fullscreen for the offline replay')
     if measure_game_scope:
      cgroup=(proc/'cgroup').read_text().strip().removeprefix('0::')
      scope_dir=Path('/sys/fs/cgroup')/cgroup.lstrip('/')
      assert scope_dir.name==scope_name,cgroup
      for filename,value in {'memory.min':'0','memory.low':'0','memory.high':'max',
                             'memory.max':'max','memory.swap.max':'max'}.items():
       assert (scope_dir/filename).read_text().strip()==value,filename
     (out/'runtime.json').write_text(json.dumps({'argv':[x.decode() for x in argv if x],
       'driver':paths,'wsi':mode,'main_cpu':main_cpu,'render_cpu':render_cpu,'worker_count':workers,'window':window,
       'private_icd':str(private_icd) if private_icd else None,
       'ib160_policy':ib160_policy,
       'diagnostic_cgroup':str(scope_dir) if scope_dir else None},indent=2)+'\n')
     break
  time.sleep(.35)
 else:raise RuntimeError('Steam profile verification timed out')
 print('COMBINED_STEAM_PROFILE',out,pid,flush=True)
 def telemetry():
  report={}
  paths={'process_io':proc/'io','rss':proc/'smaps_rollup','diskstat':Path('/sys/block/nvme0n1/stat'),
         'memory_psi':Path('/proc/pressure/memory'),'io_psi':Path('/proc/pressure/io'),
         'meminfo':Path('/proc/meminfo'),'vmstat':Path('/proc/vmstat')}
  for name,path in paths.items():report[name]=path.read_text()
  stat=(proc/'stat').read_text().rsplit(')',1)[1].split()
  report['game_page_faults']={'minor':int(stat[7]),'major':int(stat[9])}
  if test_main_pair:
   report['interrupts']=Path('/proc/interrupts').read_text()
   report['zram_stat']=Path('/sys/block/zram0/stat').read_text()
  if scope_dir is not None:
   report['game_cgroup']={name:(scope_dir/name).read_text() for name in (
     'memory.current','memory.swap.current','memory.stat','memory.events','memory.pressure','io.pressure')}
   report['thread_page_faults']={}
  report['uring_fds']=[]
  for item in (proc/'fd').iterdir():
   try:
    target=os.readlink(item)
    if 'io_uring' in target:report['uring_fds'].append(target)
   except FileNotFoundError:pass
  report['thread_ticks']={}
  report['thread_affinity']={}
  for task in (proc/'task').iterdir():
   try:
    fields=(task/'stat').read_text().rsplit(')',1)
    name=fields[0].split('(',1)[1]
    report['thread_affinity'][task.name]=[name,sorted(os.sched_getaffinity(int(task.name)))]
    if scope_dir is not None and (task.name==str(pid) or name=='VKRenderThread' or name.startswith('AsyncIOService')):
     stats=fields[1].split()
     report['thread_page_faults'][task.name]=[name,int(stats[7]),int(stats[9])]
    if re.search('audio|mixer|steamAudio',name,re.I):
     stats=fields[1].split()
     report['thread_ticks'][task.name]=[name,int(stats[11])+int(stats[12])]
   except (FileNotFoundError,ProcessLookupError):pass
  manager, compositing=compositor_state()
  report.update(window_manager=manager,x11_compositing=compositing)
  if manager=='KWin':report['kwin_compositing']='b true' if compositing else 'b false'
  return report
 def ui(cmd):
  args=['python3',str(base/'work/cs2-nuke-input.py'),str(pid),window,cmd,'--auto-console']
  result=subprocess.run(args,capture_output=True,text=True,timeout=12)
  if result.returncode and 'CS2 console did not open' in result.stderr:
   time.sleep(1.2)
   result=subprocess.run(args,capture_output=True,text=True,timeout=12)
  if result.returncode:print(result.stderr,flush=True);result.check_returncode()
 time.sleep(7)
 ui('playdemo '+demo)
 await_log('Demo Skipping finished at tick 0',timeout=45)
 def seek_for_score():
  offset=log.stat().st_size
  ui(f'demo_pause;demo_gototick {seek_tick}')
  await_log(f'Demo Skipping finished at tick {seek_tick}',offset)
  time.sleep(1.6)
  ui(f'spec_mode 1;spec_player {slot}')
  ui('spec_show_xray 0')
 for variant in (variant,):
  p=out/variant
  p.mkdir()
  seek_for_score()
  if replay_prime is not None:
   (p/'before-prime-telemetry.json').write_text(json.dumps(telemetry()))
   prime_started=time.monotonic()
   prime_marker=None
   if replay_prime=='played':
    offset=log.stat().st_size
    ui('demo_resume')
    prime_marker=await_log(r'CGameRules - unpaused on tick \d+',offset,timeout=3)
    time.sleep(max(0,prime_started+25-time.monotonic()))
    seek_for_score()
   deadline=prime_started+38
   assert time.monotonic()<deadline, 'Replay warm-up exceeded equal preparation window'
   time.sleep(max(0,deadline-time.monotonic()))
   (p/'replay-prime.json').write_text(json.dumps({'mode':replay_prime,'pid':pid,
      'seek_tick':seek_tick,'elapsed_s':time.monotonic()-prime_started,
      'resume_marker_observed':prime_marker is not None})+'\n')
  if kebab:
   ui('cl_draw_only_deathnotices 0;cl_drawhud_force_deathnotices -1')
   time.sleep(.6)
   ImageGrab.grab().save(p/'camera-proof.png')
   (p/'trueview.txt').write_text('\n'.join(line for line in read_from().splitlines()
      if 'Demo is version' in line)+'\n')
  if not hfr1_gfx:ui('cl_draw_only_deathnotices '+'1'+';cl_drawhud_force_deathnotices -1')
  time.sleep(.6)
  query_offset=log.stat().st_size
  (p/'video-runtime.txt').write_bytes(video.read_bytes())
  with (p/'overlays.txt').open('w') as evidence:
   evidence.write('\n'.join(sorted({line.split(maxsplit=5)[-1] for line in (proc/'maps').read_text().splitlines() if 'overlayrenderer' in line.lower() or 'mangohud' in line.lower()})))
  ImageGrab.grab().resize((960,540)).save(p/'before.png')
  with (p/'present.csv').open('w') as f:
   observer=[str(base/'work/cs2-xpresent-watch'),window,'32']
   if test_main_pair:
    observer=['taskset','-c','0',*observer]
   elif test_ccx1 or os.environ.get('CS2_TEST_OBSERVER_CCX0')=='1':
    observer=['taskset','-c','0-7',*observer]
   capture=subprocess.Popen(observer,stdout=f)
   diag=pmu=clock_measure=wake_measure=peak_measure=present_measure=memory_measure=None
   try:
    time.sleep(.45)
    assert capture.poll() is None
    (p/'before-telemetry.json').write_text(json.dumps(telemetry()))
    if test_peak_trace and not narrow_peak_trace:
     with (p/'peak-sched.log').open('w') as trace_log:
      peak_measure=subprocess.Popen([sys.executable,str(base/'work/cs2-kebab-peak-record.py'),str(pid),str(p)],
         stdout=trace_log,stderr=subprocess.STDOUT)
    require_same_clock()
    if ib160_policy is not None:
     probe=recent_present(p/'present.csv',time.monotonic())
     (p/'present-preflight.json').write_text(json.dumps(probe,indent=2)+'\n')
     if probe['reject_copy']:
      raise RuntimeError('The last 0.3 seconds were entirely X11 Copy; replay was not resumed')
    resume_offset=log.stat().st_size
    ui('demo_resume')
    resumed=time.monotonic()
    marker=await_log(r'CGameRules - unpaused on tick \d+',resume_offset,timeout=3)
    (p/'resume-proof.txt').write_text(marker)
    print('SCORED_STARTED',variant,resumed,flush=True)
    if hfr1_gfx:
     ImageGrab.grab().resize((960,540)).save(p/'during-start.png')
     with (p/'gfx-capture.log').open('w') as trace_log:
      present_measure=subprocess.Popen(['sudo','-n','/usr/bin/python3',str(base/'work/cs2-hfr1-gfx-record.py'),
        str(pid),str(render[0]),str(p),str(resumed)],stdout=trace_log,stderr=subprocess.STDOUT)
    if test_memory_trace:
     memory_allocator=['--allocator'] if os.environ.get('CS2_TEST_MEMORY_ALLOCATOR')=='1' else []
     with (p/'memory-capture.log').open('w') as trace_log:
      memory_measure=subprocess.Popen(['taskset','-c','0-5',sys.executable,str(base/'work/cs2-kebab-memory-record.py'),
       str(pid),str(p),str(resumed),*memory_allocator],stdout=trace_log,stderr=subprocess.STDOUT)
    if test_present_trace:
     assert not test_peak_trace and not test_wake_trace
     present_pipeline=['--pipeline'] if os.environ.get('CS2_TEST_PRESENT_PIPELINE')=='1' else []
     if os.environ.get('CS2_TEST_PRESENT_LINK_FENCES')=='1':present_pipeline.append('--link-fences')
     xorg_pid,=subprocess.check_output(['pgrep','-x','-u',str(os.getuid()),'Xorg'],text=True).split()
     with (p/'present-capture.log').open('w') as trace_log:
      present_measure=subprocess.Popen([sys.executable,str(base/'work/cs2-kebab-present-record.py'),str(pid),str(p),
         '--xorg-pid',xorg_pid,'--resume-mono',str(resumed),*present_pipeline],stdout=trace_log,stderr=subprocess.STDOUT)
    if narrow_peak_trace:
     with (p/'peak-sched.log').open('w') as trace_log:
      worker_profile=['--profile-workers'] if os.environ.get('CS2_TEST_PEAK_WORKERS')=='1' else []
      if os.environ.get('CS2_TEST_WORKER_SLEEP_STACKS')=='1':worker_profile.append('--worker-sleep-stacks')
      if os.environ.get('CS2_TEST_MAIN_PATH')=='1':worker_profile.append('--main-path')
      if os.environ.get('CS2_TEST_JOB_BREAKPOINTS')=='1':worker_profile.append('--job-breakpoints')
      if os.environ.get('CS2_TEST_MAIN_CPU_PROFILE')=='1':worker_profile.append('--main-cpu-profile')
      if os.environ.get('CS2_TEST_MMAP_LOCK')=='1':worker_profile.append('--mmap-lock')
      if os.environ.get('CS2_TEST_UPLOAD_BREAKPOINTS')=='1':worker_profile.append('--upload-breakpoints')
      if os.environ.get('CS2_TEST_SMT_PEERS')=='1':worker_profile.append('--smt-peers')
      if os.environ.get('CS2_TEST_MAIN_CORE')=='1':worker_profile.append('--main-core')
      if os.environ.get('CS2_TEST_HUD_BREAKPOINTS')=='1':worker_profile.append('--hud-breakpoints')
      if phase:=os.environ.get('CS2_TEST_ENGINE_PHASES'):
       worker_profile.append('--engine-phase-breakpoints='+('frame' if phase=='1' else phase))
      if os.environ.get('CS2_TEST_ENGINE_PHASE_IBS')=='1':worker_profile.append('--engine-phase-ibs')
      if phase_counts:worker_profile.append('--engine-phase-counts')
      peak_measure=subprocess.Popen([sys.executable,str(base/'work/cs2-kebab-peak-record.py'),str(pid),str(p),
         '--resume-mono',str(resumed),*worker_profile],stdout=trace_log,stderr=subprocess.STDOUT)
    if diagnostics:
     with (p/'diagnostic-collector.log').open('w') as diagnostic_log:
      diag=subprocess.Popen([sys.executable,str(base/'work/cs2-kebab-diag.py'),str(pid),str(p),str(resumed)],
                            stdout=diagnostic_log,stderr=subprocess.STDOUT)
    if matrix:
     time.sleep(max(0,resumed+1-time.monotonic()))
     if not phase_counts and os.environ.get('CS2_TEST_CLOCK_ONLY')!='1':
      with (p/'light-pmu.csv').open('w') as counters:
       pmu=subprocess.Popen(['sudo','-n','perf','stat','-x',';','-p',str(pid),'-e',
         '{cycles,instructions,dTLB-loads,dTLB-load-misses,l2_dtlb_misses}',
         '--','sleep','20'],stderr=counters)
     if measure_locked_cpu:
      with (p/'clock-msr.csv').open('w') as clocks:
       clock_measure=subprocess.Popen(['sudo','-n','perf','stat','-a','-A','-C',f'{render_cpu},{main_cpu}',
          '-I','1000','-x',';','-e','msr/aperf/,msr/mperf/,msr/tsc/','--','sleep','20'],stderr=clocks)
    if test_wake_trace:
     with (p/'wake-trace.log').open('w') as trace_log:
      wake_measure=subprocess.Popen([sys.executable,str(base/'work/cs2-kebab-wake-record.py'),
         str(pid),str(render_cpu),str(p),str(resumed)],stdout=trace_log,stderr=subprocess.STDOUT)
    time.sleep(max(0,resumed+24-time.monotonic()))
    ui('demo_pause')
    (p/'after-telemetry.json').write_text(json.dumps(telemetry()))
    ImageGrab.grab().resize((960,540)).save(p/'after.png')
    assert capture.wait(timeout=12)==0
    if diag is not None:
     assert diag.wait(timeout=4)==0, 'See diagnostic-collector.log'
    if pmu is not None:
     assert pmu.wait(timeout=3)==0, 'See light-pmu.csv'
    if clock_measure is not None:
     assert clock_measure.wait(timeout=3)==0, 'See clock-msr.csv'
    if wake_measure is not None:
     assert wake_measure.wait(timeout=6)==0, 'See wake-trace.log'
    if peak_measure is not None:
     assert peak_measure.wait(timeout=5)==0, 'See peak-sched.log'
    if present_measure is not None:
     assert present_measure.wait(timeout=8)==0, 'See present-capture.log'
    if memory_measure is not None:
     assert memory_measure.wait(timeout=8)==0, 'See memory-capture.log'
   finally:
    if memory_measure is not None and memory_measure.poll() is None:
     memory_measure.terminate()
     memory_measure.wait(timeout=12)
    if present_measure is not None and present_measure.poll() is None:
     present_measure.terminate()
     present_measure.wait(timeout=12)
    if capture.poll() is None:capture.terminate();capture.wait(timeout=5)
    if diag is not None and diag.poll() is None:diag.wait(timeout=26)
  require_same_clock()
  (p/'run.json').write_text(json.dumps({'stable_window_mono':[resumed+1,resumed+21],
    'resume_mono':resumed,'seek_tick':seek_tick,'xray':0,'variant':variant,'offline':True},indent=2)+'\n')
  print('SCORED_DONE',variant,flush=True)
finally:
 if pid is None and launcher is not None and launcher.poll() is None:
  try:os.killpg(launcher.pid,signal.SIGTERM)
  except ProcessLookupError:pass
 if pid and Path('/proc',str(pid)).exists():
  if window:
   try:subprocess.run(['python3',str(base/'work/cs2-nuke-input.py'),str(pid),window,'quit','--auto-console'],timeout=12)
   except subprocess.TimeoutExpired:pass
  proc=Path('/proc',str(pid))
  end=time.monotonic()+9
  while proc.exists() and time.monotonic()<end:time.sleep(.25)
  if proc.exists() and b'-insecure' in (proc/'cmdline').read_bytes().split(b'\0'):
   os.kill(pid,signal.SIGTERM)
   end=time.monotonic()+9
   while proc.exists() and time.monotonic()<end:time.sleep(.25)
 for path,data in saved.items():
  if path.read_bytes()!=data:write(path,data)
 (out/'restored.json').write_text(json.dumps({'byte_identical_cfg':{p.name:p.read_bytes()==b for p,b in saved.items()},
   'steam_launch_options_unchanged':launch_opts.replace('"',r'\"') in steam_cfg.read_text()},indent=2)+'\n')
 print('COMBINED_CLOSED',out,flush=True)

