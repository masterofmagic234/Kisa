#!/bin/sh
# Launch CS2 normally and apply CPU affinity to this launch's CS2 process only.
"$@" &
launch_pid=$!
python3 - "$launch_pid" <<'PY' &
import os
import subprocess
import sys
import time
from pathlib import Path

root = int(sys.argv[1])
main_cpu, render_cpu = 14, 6
reserved = {6, 7, 14, 15}

def descendant(pid):
    while pid > 1 and pid != root:
        pid = int((Path('/proc') / str(pid) / 'stat').read_text().rsplit(')',1)[1].split()[1])
    return pid == root

def game():
    ids = subprocess.run(['pgrep','-x','-u',str(os.getuid()),'cs2'], text=True, capture_output=True)
    for raw in ids.stdout.split():
        try:
            pid = int(raw)
            proc = Path('/proc') / raw
            if descendant(pid) and os.readlink(proc/'exe').endswith('/game/bin/linuxsteamrt64/cs2'):
                return pid, proc
        except (OSError, ValueError):
            continue

def threads(proc):
    result = {}
    for item in (proc/'task').iterdir():
        try:
            result[int(item.name)] = (item/'comm').read_text().rstrip('\n')
        except FileNotFoundError:
            continue
    return result

original = {}
try:
    stop = time.monotonic()+45
    while time.monotonic()<stop:
        os.kill(root,0)
        match = game()
        if match:
            pid, proc = match
            current = threads(proc)
            if 'VKRenderThread' in current.values() and 'GlobPool/0' in current.values():
                break
        time.sleep(.3)
    else:
        sys.exit(0)
    time.sleep(8)
    initial = os.sched_getaffinity(pid)
    if initial != set(range(16)):
        sys.exit(0)
    for cpu, expected in [(main_cpu,'14-15'),(render_cpu,'6-7')]:
        topology = Path(f'/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list')
        if topology.read_text().strip() != expected:
            sys.exit(0)
    pool = initial-reserved
    # Catch startup threads that inherit the reserved CPU masks from their parent.
    stop = time.monotonic()+48
    while time.monotonic()<stop:
        for tid, name in threads(proc).items():
            if tid in original:
                continue
            try:
                old = os.sched_getaffinity(tid)
                mask = {main_cpu} if tid==pid else {render_cpu} if name=='VKRenderThread' else old & pool or pool
                os.sched_setaffinity(tid,mask)
                original[tid]=old
            except ProcessLookupError:
                continue
        time.sleep(.4)
except (OSError, ValueError):
    for tid, mask in original.items():
        try:
            os.sched_setaffinity(tid,mask)
        except OSError:
            pass
PY
watcher=$!
trap 'kill "$watcher" 2>/dev/null || :; kill "$launch_pid" 2>/dev/null || :' HUP INT TERM
wait "$launch_pid"
status=$?
kill "$watcher" 2>/dev/null || :
wait "$watcher" 2>/dev/null || :
exit "$status"
