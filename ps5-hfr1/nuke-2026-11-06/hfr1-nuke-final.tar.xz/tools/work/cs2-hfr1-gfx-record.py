#!/usr/bin/env python3
"""Record HFR1 kernel tracepoints in a disposable tracefs instance."""
import json
import os
from pathlib import Path
import signal
import sys
import time

pid, render, out, resume = sys.argv[1:]
out, resume = Path(out), float(resume)
game = Path("/proc", pid)
argv = (game / "cmdline").read_bytes().split(b"\0")
if (os.geteuid() or os.uname().release != "7.2.3-ps5-hfr1"
        or argv.count(b"-insecure") != 1 or b"-secure" in argv
        or (game / "task" / render / "comm").read_text().strip() != "VKRenderThread"):
    raise SystemExit("Expected an offline HFR1 replay and its render thread")

def stop(sig, _):
    raise InterruptedError(sig)

for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
    signal.signal(sig, stop)

switch = " || ".join(f"prev_pid == {tid} || next_pid == {tid}" for tid in (pid, render))
wake = f"pid == {pid} || pid == {render}"
events = {
    **{f"gpu_scheduler/drm_sched_job_{name}": None
       for name in ("queue", "run", "done", "unschedulable", "add_dep")},
    "dma_fence/dma_fence_signaled": 'driver == "drm_sched" || driver == "amdgpu"',
    "amdgpu/amdgpu_cs_ioctl": None,
    "amdgpu/amdgpu_sched_run_job": None,
    "sched/sched_switch": switch,
    "sched/sched_waking": wake,
    "syscalls/sys_enter_ioctl": "cmd == 0xc0186444",
}
root = Path("/sys/kernel/tracing/instances", f"hfr1-cs2-{os.getpid()}")
def set_value(name, value):
    (root / name).write_text(f"{value}\n")

root.mkdir()
try:
    set_value("tracing_on", 0)
    set_value("trace_clock", "mono")
    set_value("current_tracer", "nop")
    set_value("buffer_size_kb", 16384)
    (root / "trace").write_text("")
    for name, filter_value in events.items():
        if filter_value is not None:
            set_value(f"events/{name}/filter", filter_value)
        set_value(f"events/{name}/enable", 1)
    time.sleep(max(0, resume + 1 - time.monotonic()))
    set_value("tracing_on", 1)
    start = time.monotonic()
    time.sleep(max(0, resume + 17 - time.monotonic()))
    set_value("tracing_on", 0)
    end = time.monotonic()
    stats = {f.parent.name: f.read_text() for f in sorted(root.glob("per_cpu/cpu*/stats"))}
    (out / "gfx-capture.json").write_text(json.dumps({
        "window_mono": [start, end], "pid": int(pid), "render_tid": int(render),
        "clock": (root / "trace_clock").read_text().strip(),
        "stats": stats, "filters": events,
    }, indent=2) + "\n")
    with (root / "trace").open("rb") as source, (out / "hfr1_gfx_trace.log").open("wb") as dest:
        while chunk := source.read(128 * 1024):
            dest.write(chunk)
finally:
    try:
        set_value("tracing_on", 0)
    finally:
        root.rmdir()
