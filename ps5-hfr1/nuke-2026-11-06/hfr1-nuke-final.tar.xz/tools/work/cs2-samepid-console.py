#!/usr/bin/env python3
"""Restricted offline console typing; --check-keymap only reads XKB."""
import ctypes as c
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

SYMBOLS = {' ': 'space', ';': 'semicolon', '-': 'minus', '/': 'slash', '.': 'period', '_': 'underscore'}
CONTROLS = ('Escape', 'grave', 'Return', 'Shift_L')
VOCABULARY = 'abcdefghijklmnopqrstuvwxyz0123456789 _./;-'


class XkbState(c.Structure):
    _fields_ = [('group', c.c_ubyte), ('locked_group', c.c_ubyte),
                ('base_group', c.c_ushort), ('latched_group', c.c_ushort),
                ('mods', c.c_ubyte), ('base_mods', c.c_ubyte),
                ('latched_mods', c.c_ubyte), ('locked_mods', c.c_ubyte),
                ('compat_state', c.c_ubyte), ('grab_mods', c.c_ubyte),
                ('compat_grab_mods', c.c_ubyte), ('lookup_mods', c.c_ubyte),
                ('compat_lookup_mods', c.c_ubyte), ('ptr_buttons', c.c_ushort)]


def open_xkb():
    x = c.CDLL('libX11.so.6')
    x.XOpenDisplay.argtypes, x.XOpenDisplay.restype = [c.c_char_p], c.c_void_p
    x.XCloseDisplay.argtypes = [c.c_void_p]
    x.XStringToKeysym.argtypes, x.XStringToKeysym.restype = [c.c_char_p], c.c_ulong
    x.XkbLookupKeySym.argtypes = [c.c_void_p, c.c_ubyte, c.c_uint, c.POINTER(c.c_uint), c.POINTER(c.c_ulong)]
    x.XkbLookupKeySym.restype = c.c_int
    x.XkbGetState.argtypes, x.XkbGetState.restype = [c.c_void_p, c.c_uint, c.POINTER(XkbState)], c.c_int
    x.XkbLockGroup.argtypes, x.XkbLockGroup.restype = [c.c_void_p, c.c_uint, c.c_uint], c.c_int
    x.XSync.argtypes = [c.c_void_p, c.c_int]
    display = x.XOpenDisplay(None)
    if not display:
        raise RuntimeError('No X11 display')
    state = XkbState()
    if x.XkbGetState(display, 0x100, c.byref(state)):
        x.XCloseDisplay(display)
        raise RuntimeError('Cannot read XKB state')
    return x, display, state


def lookup(x, display, code, group, modifiers):
    consumed, symbol = c.c_uint(), c.c_ulong()
    # Effective translation applies per-key group wrapping and key types.
    ok = x.XkbLookupKeySym(display, code, (modifiers & 255) | ((group & 3) << 13),
                           c.byref(consumed), c.byref(symbol))
    return symbol.value if ok else 0


def discover(x, display, state, command):
    if state.mods & ~16:
        raise RuntimeError(f'Release keyboard modifiers/CapsLock; mods={state.mods}')
    if state.base_group or state.latched_group:
        raise RuntimeError(f'Release layout latch: base={state.base_group} latched={state.latched_group}')
    targets = {char: SYMBOLS.get(char, char) for char in sorted(set(command))}
    targets.update({key: key for key in CONTROLS})
    failures = []
    for group in dict.fromkeys([int(state.group), 0, 1, 2, 3]):
        mapping, missing = {}, []
        for char, name in targets.items():
            target = x.XStringToKeysym(name.encode())
            choices = [(shift, code) for shift in (False, True) for code in range(8, 256)
                       if target and lookup(x, display, code, group, state.mods | int(shift)) == target]
            if not choices:
                missing.append({'char': char, 'keysym': name, 'target': int(target)})
            else:
                shift, code = min(choices)
                mapping[char] = {'keycode': code, 'shift': shift, 'keysym': name, 'target': int(target)}
        if not missing and all(not mapping[key]['shift'] for key in CONTROLS):
            return group, mapping, failures
        failures.append({'group': group, 'missing': missing,
                         'shifted_controls': [key for key in CONTROLS if key in mapping and mapping[key]['shift']]})
    raise RuntimeError('No complete XKB command mapping: ' + json.dumps(failures))


def keymap_only():
    x, display, state = open_xkb()
    try:
        group, mapping, failures = discover(x, display, state, VOCABULARY)
        return {'status': 'READ_ONLY_KEYMAP_PASS', 'original_effective_group': state.group,
                'original_locked_group': state.locked_group, 'modifiers': state.mods,
                'selected_group': group, 'mapping': mapping, 'rejected_groups': failures,
                'keypresses_sent': 0, 'keyboard_group_changed': False}
    finally:
        x.XCloseDisplay(display)


def main():
    if sys.argv[1:] == ['--check-keymap']:
        print(json.dumps(keymap_only(), indent=2))
        return
    if len(sys.argv) != 6 or os.geteuid() == 0:
        raise ValueError('Expected PID STARTTIME WARM_CSV WINDOW COMMAND as desktop user')
    pid, start, csv, window, command = sys.argv[1:]
    if not pid.isdigit() or not start.isdigit() or not re.fullmatch(r'0x[0-9a-fA-F]+', window):
        raise ValueError('Invalid process/window identity')
    if not re.fullmatch(r'cs2-samepid-[A-Za-z0-9_.-]+-warm\.csv', csv):
        raise ValueError('Unexpected warm CSV')
    if not re.fullmatch(r'[a-z0-9_ ./;\-]+', command) or len(command) > 600:
        raise ValueError('Unexpected command characters')
    parts = [p.strip().split()[0] for p in command.split(';') if p.strip()]
    if parts != ['echo', 'timedemo_start', 'timedemo_end', 'demo_quitafterplayback',
                 'spec_autodirector', 'spec_lock_to_accountid', 'timedemo']:
        raise ValueError('Only generated offline timedemo commands are accepted')

    def validate():
        proc = Path('/proc') / pid
        args = (proc / 'cmdline').read_bytes().split(b'\0')
        fields = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
        if (proc.stat().st_uid != os.getuid() or fields[19] != start
                or args.count(b'-insecure') != 1 or b'-secure' in args or args.count(csv.encode()) != 1
                or not os.readlink(proc / 'exe').endswith('/game/bin/linuxsteamrt64/cs2')):
            raise RuntimeError('Offline game identity changed')
        active = subprocess.check_output(['xprop', '-root', '_NET_ACTIVE_WINDOW'], text=True, timeout=2).split()[-1]
        if int(active, 16) != int(window, 16):
            raise RuntimeError('CS2 lost focus; stopping input')

    validate()
    x, display, state = open_xkb()
    held, changed_group = set(), False
    try:
        group, mapping, failures = discover(x, display, state, command)
        print(json.dumps({'selected_group': group, 'mapping': mapping, 'rejected_groups': failures,
                          'original_locked_group': state.locked_group}), flush=True)
        t = c.CDLL('libXtst.so.6')  # Never loaded in the read-only preflight.
        t.XTestFakeKeyEvent.argtypes = [c.c_void_p, c.c_uint, c.c_int, c.c_ulong]

        def event(code, down):
            t.XTestFakeKeyEvent(display, code, int(down), 0)
            x.XSync(display, 0)
            (held.add if down else held.discard)(code)

        def tap(char):
            entry = mapping[char]
            if entry['shift']:
                event(mapping['Shift_L']['keycode'], True)
            event(entry['keycode'], True)
            time.sleep(.02)
            event(entry['keycode'], False)
            if entry['shift']:
                event(mapping['Shift_L']['keycode'], False)
            time.sleep(.013)

        def interrupted(number, _frame):
            raise RuntimeError(f'Console input interrupted: {number}')

        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
            signal.signal(sig, interrupted)
        if not x.XkbLockGroup(display, 0x100, group):
            raise RuntimeError(f'Cannot select verified keyboard group={group}')
        changed_group = True
        x.XSync(display, 0)
        current = XkbState()
        if x.XkbGetState(display, 0x100, c.byref(current)) or current.group != group:
            raise RuntimeError(f'Effective group mismatch: requested={group} actual={current.group}')
        tap('Escape')
        time.sleep(.1)
        validate()
        tap('grave')
        time.sleep(.23)
        for char in command:
            validate()
            if (x.XkbGetState(display, 0x100, c.byref(current))
                    or current.group != group or current.mods != state.mods):
                raise RuntimeError(f'Keyboard changed before char={char!r} group={current.group} mods={current.mods}')
            expected = mapping[char]
            actual = lookup(x, display, expected['keycode'], group, state.mods | int(expected['shift']))
            if actual != expected['target']:
                raise RuntimeError(f'Keymap changed: char={char!r} group={group} keycode={expected["keycode"]} shift={expected["shift"]} expected={expected["target"]} actual={actual}')
            tap(char)
        validate()
        tap('Return')
        time.sleep(.18)
        validate()
        tap('grave')
    finally:
        for code in held:
            t.XTestFakeKeyEvent(display, code, 0, 0)
        if changed_group:
            x.XkbLockGroup(display, 0x100, state.locked_group)
            x.XSync(display, 0)
        x.XCloseDisplay(display)


if __name__ == '__main__':
    main()
