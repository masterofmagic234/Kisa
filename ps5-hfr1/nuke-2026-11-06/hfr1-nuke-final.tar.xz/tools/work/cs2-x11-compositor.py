"""Read the compositor state from the window manager of the current X11 display."""

import ctypes
import re
import subprocess


def active_window():
    value = subprocess.check_output(["xprop", "-root", "_NET_ACTIVE_WINDOW"], text=True, timeout=3)
    windows = re.findall(r"\b0x[0-9a-f]+\b", value.partition("#")[2], re.I)
    return next((window for window in windows if int(window, 16)), None)


def fullscreen_xfwm(window):
    state = subprocess.check_output(["xprop", "-id", window, "_NET_WM_STATE"], text=True, timeout=3)
    if "_NET_WM_STATE_FULLSCREEN" in state:
        return
    xfwm_shortcut(window, "F11", "fullscreen_key")


def xfwm_shortcut(window, key_name, action):
    shortcut = subprocess.check_output(["xfconf-query", "-c", "xfce4-keyboard-shortcuts", "-p",
                                        f"/xfwm4/custom/<Alt>{key_name}"], text=True, timeout=3).strip()
    if active_window() != window or shortcut != action:
        raise RuntimeError("Xfwm4 shortcut or game focus changed")
    x11 = ctypes.CDLL("libX11.so.6")
    xtest = ctypes.CDLL("libXtst.so.6")
    x11.XOpenDisplay.argtypes = [ctypes.c_char_p]
    x11.XOpenDisplay.restype = ctypes.c_void_p
    x11.XStringToKeysym.argtypes = [ctypes.c_char_p]
    x11.XStringToKeysym.restype = ctypes.c_ulong
    x11.XKeysymToKeycode.argtypes = [ctypes.c_void_p, ctypes.c_ulong]
    x11.XKeysymToKeycode.restype = ctypes.c_ubyte
    x11.XSync.argtypes = [ctypes.c_void_p, ctypes.c_int]
    x11.XCloseDisplay.argtypes = [ctypes.c_void_p]
    xtest.XTestFakeKeyEvent.argtypes = [ctypes.c_void_p, ctypes.c_uint, ctypes.c_int, ctypes.c_ulong]
    display = x11.XOpenDisplay(None)
    if not display:
        raise RuntimeError("Cannot open the Xfce display")
    try:
        alt, letter = (x11.XKeysymToKeycode(display, x11.XStringToKeysym(key))
                       for key in (b"Alt_L", key_name.encode()))
        if not alt or not letter:
            raise RuntimeError("X11 shortcut keycodes unavailable")
        for key, pressed in ((alt, True), (letter, True), (letter, False), (alt, False)):
            xtest.XTestFakeKeyEvent(display, key, pressed, 0)
        x11.XSync(display, 0)
    finally:
        x11.XCloseDisplay(display)


def compositor_state():
    root = subprocess.check_output(["xprop", "-root", "_NET_SUPPORTING_WM_CHECK"], text=True, timeout=3)
    window = root.strip().split()[-1]
    manager = subprocess.check_output(["xprop", "-id", window, "_NET_WM_NAME"], text=True, timeout=3)
    if manager.strip().endswith('"Xfwm4"'):
        state = subprocess.check_output(["xfconf-query", "-c", "xfwm4", "-p", "/general/use_compositing"],
                                        text=True, timeout=3).strip()
        if state not in ("true", "false"):
            raise ValueError(f"Unexpected Xfwm4 compositor state: {state}")
        return "Xfwm4", state == "true"
    state = subprocess.check_output(["busctl", "--user", "get-property", "org.kde.KWin", "/Compositor",
                                     "org.kde.kwin.Compositing", "active"], text=True, timeout=3).strip()
    if state not in ("b true", "b false"):
        raise ValueError(f"Unexpected KWin compositor state: {state}")
    return "KWin", state == "b true"
