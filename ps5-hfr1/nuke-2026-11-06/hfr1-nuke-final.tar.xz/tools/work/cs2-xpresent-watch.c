#define _POSIX_C_SOURCE 200809L
#include <inttypes.h>
#include <poll.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <xcb/present.h>
#include <xcb/xcb.h>

static double monotonic_time(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return (double)t.tv_sec + (double)t.tv_nsec / 1000000000.0;
}

int main(int argc, char **argv)
{
    if (argc != 3)
        return 2;
    const xcb_window_t window = strtoul(argv[1], NULL, 0);
    const double duration = strtod(argv[2], NULL);
    if (!window || duration <= 0 || duration > 180)
        return 2;

    xcb_connection_t *connection = xcb_connect(NULL, NULL);
    if (xcb_connection_has_error(connection))
        return 1;
    const xcb_query_extension_reply_t *extension =
        xcb_get_extension_data(connection, &xcb_present_id);
    if (!extension || !extension->present)
        return 1;

    const xcb_present_event_t id = xcb_generate_id(connection);
    uint32_t stamp = 0;
    xcb_special_event_t *queue =
        xcb_register_for_special_xge(connection, &xcb_present_id, id, &stamp);
    if (!queue)
        return 1;

    xcb_generic_error_t *error = xcb_request_check(connection,
        xcb_present_select_input_checked(connection, id, window, XCB_PRESENT_EVENT_MASK_COMPLETE_NOTIFY));
    if (error) {
        fprintf(stderr, "Present select failed, X error %u\n", error->error_code);
        free(error);
        return 1;
    }
    setvbuf(stdout, NULL, _IOLBF, 0);
    printf("mono,ust_us,msc,serial,kind,mode\n");
    const double end = monotonic_time() + duration;
    struct pollfd fd = { .fd = xcb_get_file_descriptor(connection), .events = POLLIN };
    while (monotonic_time() < end && !xcb_connection_has_error(connection)) {
        xcb_generic_event_t *generic;
        while ((generic = xcb_poll_for_special_event(connection, queue))) {
            const xcb_present_complete_notify_event_t *event = (const void *)generic;
            if (event->event_type == XCB_PRESENT_COMPLETE_NOTIFY)
                printf("%.9f,%" PRIu64 ",%" PRIu64 ",%" PRIu32 ",%u,%u\n",
                       monotonic_time(), event->ust, event->msc, event->serial,
                       event->kind, event->mode);
            free(generic);
        }
        poll(&fd, 1, 100);
    }
    xcb_unregister_for_special_event(connection, queue);
    xcb_disconnect(connection);
    return 0;
}
