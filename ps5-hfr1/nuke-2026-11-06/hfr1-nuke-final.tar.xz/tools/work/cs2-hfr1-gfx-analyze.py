#!/usr/bin/env python3
"""Analyze an offline HFR1 DRM scheduler and X11 Present capture."""

import argparse
from bisect import bisect_left
from collections import Counter, defaultdict
import csv
from decimal import Decimal
import json
import math
from pathlib import Path
import re
from statistics import median


ROW = re.compile(
    r"^\s*(?P<comm>.+)-(?P<tid>\d+)\s+(?:\([^)]*\)\s+)?"
    r"\[(?P<cpu>\d+)\]\s+(?:\S+\s+)?(?P<stamp>\d+\.\d+):\s+"
    r"(?P<event>[\w:]+)(?::\s*|\()(?P<detail>.*)$"
)
FENCE = re.compile(r"\bfence=(\d+):(\d+)")
SIGNAL = re.compile(r"\bdriver=(\S+)\s+timeline=(\S+)\s+context=(\d+)\s+seqno=(\d+)")
RING = re.compile(r"\bring(?:_name)?=([^,\s]+)")
DEV = re.compile(r"\bdev=([^,\s]+)")
CLIENT = re.compile(r"\bclient_id[:=]\s*(\d+)")
AMD_CS = re.compile(r"\bcmd\s*[:=]\s*0x0*c0186444\b", re.I)
STAGES = {
    "drm_sched_job_queue": "Q",
    "drm_sched_job_run": "R",
    "drm_sched_job_done": "D",
    "amdgpu_cs_ioctl": "I",
    "amdgpu_sched_run_job": "A",
}
UINT32_MAX = (1 << 32) - 1


def ns(value):
    return int(Decimal(str(value)) * 1_000_000_000)


def ms(value):
    return round(value / 1_000_000, 6)


def summary(values):
    ordered = sorted(values)
    result = {"n": len(ordered)}
    if ordered:
        for label, q in (("p50", .50), ("p95", .95), ("p99", .99), ("max", 1)):
            result[f"{label}_ms"] = ms(ordered[math.ceil(len(ordered) * q) - 1])
    return result


def known_tids(path, metadata):
    result = {int(tid): None for tid in metadata.get("game_tids", [])}
    before, after = (path / f"{phase}-telemetry.json" for phase in ("before", "after"))
    if before.is_file() and after.is_file():
        snapshots = [json.loads(f.read_text()).get("thread_affinity", {}) for f in (before, after)]
        first, last = snapshots
        for tid in first.keys() & last.keys():
            if first[tid][0] == last[tid][0]:
                result[int(tid)] = first[tid][0]
    result[int(metadata["pid"])] = "cs2"
    result[int(metadata["render_tid"])] = "VKRenderThread"
    return result


def parse_trace(path):
    stages = defaultdict(lambda: defaultdict(list))
    signals = defaultdict(list)
    dependency_edges = defaultdict(set)
    unschedulable = defaultdict(list)
    entries, issues, counts = {}, Counter(), Counter()
    bounds, last_by_cpu = [], {}
    with path.open(errors="replace") as stream:
        for line in stream:
            if re.search(r"\bLOST\s+\d+\s+EVENTS?\b", line, re.I):
                issues["visible lost records"] += 1
            match = ROW.match(line)
            if not match:
                if not line.lstrip().startswith("#") and line.strip():
                    issues["unparsed trace lines"] += 1
                continue
            comm, tid, cpu, stamp, event, detail = match.groups()
            tid, cpu, stamp = int(tid), int(cpu), ns(stamp)
            if stamp < last_by_cpu.get(cpu, stamp):
                issues["reversed timestamp on one CPU"] += 1
            last_by_cpu[cpu] = stamp
            bounds.append(stamp)
            event = event.rsplit(":", 1)[-1]
            if event == "sys_ioctl":
                event = "sys_enter_ioctl"
            counts[event] += 1
            if event == "sys_enter_ioctl" and AMD_CS.search(detail):
                entries[tid] = stamp
            elif event == "dma_fence_signaled":
                if fields := SIGNAL.search(detail):
                    driver, ring, context, seq = fields.groups()
                    signals[driver, int(context), int(seq)].append((stamp, ring))
                else:
                    issues["unparsed fence signal"] += 1
            elif event in ("drm_sched_job_add_dep", "drm_sched_job_unschedulable"):
                keys = [tuple(map(int, key)) for key in FENCE.findall(detail)]
                if len(keys) != 2:
                    issues["unparsed dependency edge"] += 1
                elif event.endswith("unschedulable"):
                    unschedulable[keys[0]].append((stamp, keys[1]))
                else:
                    dependency_edges[keys[0]].add(keys[1])
            elif stage := STAGES.get(event):
                if not (fence := FENCE.search(detail)):
                    issues[f"unparsed {stage} event"] += 1
                    continue
                key = tuple(map(int, fence.groups()))
                ring, dev, client = RING.search(detail), DEV.search(detail), CLIENT.search(detail)
                stages[key][stage].append({
                    "ns": stamp, "comm": comm.strip(), "tid": tid,
                    "ring": ring[1] if ring else None, "device": dev[1] if dev else None,
                    "client_id": int(client[1]) if client else None,
                    "cs_enter_ns": entries.get(tid) if stage == "I" else None,
                })
    if len(bounds) < 2:
        raise ValueError("Fewer than two recognized tracefs rows")
    return stages, signals, dependency_edges, unschedulable, counts, issues, (min(bounds), max(bounds))


def correlate(stages, signals, dependencies, unschedulable, tids, start, end, issues):
    def owner(record):
        tid = record["tid"]
        return tid in tids and (tids[tid] is None or record["comm"] == tids[tid])

    queues, jobs, clients = [], [], set()
    other_clients = Counter()
    for key, marks in stages.items():
        if len(marks["Q"]) != 1:
            if len(marks["Q"]) > 1:
                issues["ambiguous Q key"] += 1
            continue
        q, = marks["Q"]
        if not start <= q["ns"] <= end:
            continue
        mine = owner(q)
        if mine and q["client_id"]:
            clients.add(q["client_id"])
        if not (q["ring"] or "").startswith("gfx"):
            continue
        queue = {"fence": key, "queue": q, "owned": mine}
        queues.append(queue)
        if len(marks["R"]) != 1 or len(marks["D"]) != 1:
            if mine:
                issues["owned GFX Q missing or ambiguous R/D"] += 1
            continue
        r, = marks["R"]
        d, = marks["D"]
        if (not q["ns"] <= r["ns"] <= d["ns"] or
                any(q[field] != r[field] for field in ("device", "ring", "client_id"))):
            issues["invalid Q/R/D time or ring/client identity"] += 1
            continue

        job = queue | {"R": r["ns"], "D": d["ns"], "S": None, "I": None, "A": None,
                       "cs_enter": None, "deps": sorted(dependencies[key]),
                       "observed_unschedulable": unschedulable[key]}
        context, seq = key
        if 0 < context <= UINT32_MAX and seq <= UINT32_MAX:
            candidates = signals["drm_sched", context - 1, seq]
            if len(candidates) == 1:
                when, timeline = candidates[0]
                if timeline == q["ring"] and r["ns"] <= when <= d["ns"]:
                    job["S"] = when
            if mine and job["S"] is None:
                issues["owned GFX Q/R/D missing or ambiguous scheduled S"] += 1
        elif mine:
            issues["owned GFX scheduler fence outside u32 signal format"] += 1

        if len(marks["I"]) == 1:
            marker, = marks["I"]
            if marker["tid"] == q["tid"] and marker["ring"] == q["ring"] and marker["ns"] <= q["ns"]:
                job["I"] = marker["ns"]
                if (entered := marker["cs_enter_ns"]) is not None and entered <= marker["ns"]:
                    job["cs_enter"] = entered
        if len(marks["A"]) == 1:
            driver, = marks["A"]
            if driver["ring"] == q["ring"] and r["ns"] <= driver["ns"] <= d["ns"]:
                job["A"] = driver["ns"]
        jobs.append(job)

    for item in queues:
        q = item["queue"]
        if not item["owned"] and q["client_id"] in clients:
            other_clients[q["comm"], q["tid"], q["client_id"]] += 1
    return queues, jobs, sorted(clients), other_clients


def buffer_loss(metadata):
    stats = {}
    for cpu, content in metadata.get("stats", {}).items():
        stats[cpu] = {key: int(value) for key, value in re.findall(
            r"^\s*(overrun|commit overrun|dropped events):\s*(\d+)", content, re.M)}
    return {"by_cpu": stats, "total": sum(sum(cpu.values()) for cpu in stats.values()),
            "complete_cpu_fields": bool(stats) and all(len(cpu) == 3 for cpu in stats.values())}


def read_present(path, start, end):
    rows = []
    with path.open(newline="") as stream:
        for row in csv.DictReader(stream):
            when = ns(row["mono"])
            ust = int(row["ust_us"]) * 1000
            if row["kind"] != "0" or not start <= ust <= end:
                continue
            rows.append({"receipt": when, "ust": ust, "msc": int(row["msc"]),
                         "serial": int(row["serial"]), "mode": int(row["mode"])})
    if len(rows) < 2:
        raise ValueError("Fewer than two pixmap completions in the trace window")
    skew = median(row["receipt"] - row["ust"] for row in rows)
    if abs(skew) > 50_000_000:
        raise ValueError("Present UST and kernel monotonic clocks do not plausibly align")
    return rows, skew


def clipped_overlap(spans, left, right):
    merged = []
    for start, end in sorted((max(left, a), min(right, b)) for a, b in spans if a < right and b > left):
        if merged and start <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], end)
        else:
            merged.append([start, end])
    return sum(b - a for a, b in merged)


def frame_report(rows, queues, jobs, start, end, long_msc, lookback):
    counts, issues = Counter(), Counter()
    visible = Counter(row["serial"] for row in rows)
    durations, frames, grouped = [], [], defaultdict(lambda: defaultdict(list))
    for first, last in zip(rows, rows[1:]):
        left, right = first["ust"], last["ust"]
        step = last["msc"] - first["msc"]
        if last["receipt"] <= first["receipt"]:
            issues["nonincreasing receipt"] += 1
            continue
        if first["mode"] == 2 or last["mode"] == 2:
            issues["adjacent to SKIP"] += 1
            continue
        if visible[first["serial"]] != 1 or visible[last["serial"]] != 1:
            issues["adjacent to duplicate serial"] += 1
            continue
        if right <= left or step <= 0:
            issues["nonpositive UST or MSC"] += 1
            continue
        counts[step] += 1
        durations.append(right - left)
        group = grouped[f"modes_{first['mode']}_{last['mode']}_msc_{step}"]
        group["duration"].append(right - left)
        covered = start <= left <= right <= end
        owned_overlap = clipped_overlap(((j["R"], j["D"]) for j in jobs if j["owned"]), left, right)
        other_overlap = clipped_overlap(((j["R"], j["D"]) for j in jobs if not j["owned"]), left, right)
        if covered:
            group["owned_run_to_done_union"].append(owned_overlap)
            group["other_run_to_done_union"].append(other_overlap)
        else:
            issues["Present gap outside observed trace coverage"] += 1
        if step < long_msc:
            continue
        nearest = bisect_left(queues, left)
        recent = [
            {"fence": j["fence"], "owned": j["owned"], "ring": j["queue"]["ring"],
             "device": j["queue"]["device"], "client_id": j["queue"]["client_id"],
             "queue_tid": j["queue"]["tid"], "queue_comm": j["queue"]["comm"],
             "Q_mono_ns": j["queue"]["ns"], **{f"{k}_mono_ns": j[k] for k in ("R", "S", "D", "I", "A")},
             "cs_enter_mono_ns": j["cs_enter"], "Q_to_R_ms": ms(j["R"] - j["queue"]["ns"]),
             "R_to_D_ms": ms(j["D"] - j["R"]), "deps": j["deps"],
             "observed_unschedulable": j["observed_unschedulable"]}
            for j in jobs if j["queue"]["ns"] < right and j["D"] >= left - lookback
        ]
        frames.append({
            "first": first, "last": last, "delta_msc": step, "ust_gap_ms": ms(right - left),
            "receipt_gap_ms": ms(last["receipt"] - first["receipt"]),
            "fully_inside_observed_trace": covered,
            "owned_GFX_Q_mono_ns": queues[nearest:bisect_left(queues, right)],
            "previous_owned_GFX_Q_mono_ns": queues[nearest - 1] if nearest else None,
            "owned_run_to_done_union_ms": ms(owned_overlap), "other_run_to_done_union_ms": ms(other_overlap),
            "recent_jobs": recent,
        })
    slow = sorted(durations, reverse=True)[:math.ceil(len(durations) / 100)]
    return {"pixmap_completions": len(rows), "modes": dict(Counter(r["mode"] for r in rows)),
            "delta_msc": dict(counts), "issues": dict(issues), "duration": summary(durations),
            "avg_fps_by_ust_span": len(durations) * 1e9 / (rows[-1]["ust"] - rows[0]["ust"])
            if rows[-1]["ust"] > rows[0]["ust"] else None,
            "one_percent_low_fps": 1e9 * len(slow) / sum(slow) if slow else None,
            "by_mode_and_delta_msc": {key: {k: summary(v) for k, v in group.items()}
                                     for key, group in grouped.items()},
            "long_frames": sorted(frames, key=lambda frame: frame["ust_gap_ms"], reverse=True)}


def report(path, long_msc, lookback_ms):
    metadata = json.loads((path / "gfx-capture.json").read_text())
    start, end = map(ns, metadata["window_mono"])
    if start >= end or "[mono]" not in metadata["clock"]:
        raise ValueError("Expected a positive interval and trace_clock=mono")
    tids = known_tids(path, metadata)
    stages, signals, deps, unsched, counts, issues, bounds = parse_trace(path / "hfr1_gfx_trace.log")
    queues, jobs, clients, other_clients = correlate(stages, signals, deps, unsched, tids, start, end, issues)
    first, last = max(start, bounds[0]), min(end, bounds[1])
    owned = [j for j in jobs if j["owned"]]
    mine = sorted(row["queue"]["ns"] for row in queues if row["owned"])
    metrics = {
        "Q_to_Q": summary(b - a for a, b in zip(mine, mine[1:])),
        "Q_to_R": summary(j["R"] - j["queue"]["ns"] for j in owned),
        "R_to_A_driver_entry": summary(j["A"] - j["R"] for j in owned if j["A"] is not None),
        "R_to_S_scheduled": summary(j["S"] - j["R"] for j in owned if j["S"] is not None),
        "S_scheduled_to_D": summary(j["D"] - j["S"] for j in owned if j["S"] is not None),
        "R_to_D": summary(j["D"] - j["R"] for j in owned),
        "Q_to_D": summary(j["D"] - j["queue"]["ns"] for j in owned),
        "CS_marker_to_Q": summary(j["queue"]["ns"] - j["I"] for j in owned if j["I"] is not None),
        "CS_ioctl_enter_to_Q": summary(j["queue"]["ns"] - j["cs_enter"] for j in owned
                                      if j["cs_enter"] is not None),
    }
    rows, skew = read_present(path / "present.csv", start, end)
    loss = buffer_loss(metadata)
    return {
        "capture": str(path.resolve()), "requested_window_mono_ns": [start, end],
        "observed_window_mono_ns": [first, last], "known_game_tids": tids, "game_client_ids": clients,
        "same_client_unattributed_GFX_Q": [{"comm": comm, "tid": tid, "client_id": client, "n": count}
                                          for (comm, tid, client), count in other_clients.most_common()],
        "trace": {"counts": dict(counts), "loss": loss, "issues": dict(issues),
                  "clean_loss_accounting": loss["complete_cpu_fields"] and not loss["total"]
                  and not issues["visible lost records"]},
        "GFX_Q_owned": len(mine), "GFX_QRD_owned": len(owned), "GFX_QRD_other": len(jobs) - len(owned),
        "owned_GFX_timings": metrics, "median_Present_receipt_minus_UST_ms": ms(skew),
        "timestamp_unit": "nanoseconds",
        "present": frame_report(rows, mine, jobs, first, last, long_msc, ns(lookback_ms) // 1000),
        "interpretation": [
            "Q/R/D join the unique 64-bit scheduler finished fence. S is its scheduled software fence.",
            "R is host dispatch before driver run_job. R→D includes enqueue, execution, and completion handling.",
            "CS ioctl enter→Q is a pre-queue prefix joined through the same-fence AMDGPU CS marker, not ioctl duration.",
            "Present associations are monotonic-window overlap only, not per-frame fence ownership or scanout latency.",
            "Unknown or same-client-only queue owners are excluded from owned metrics.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=Path)
    parser.add_argument("--long-msc", type=int, default=3)
    parser.add_argument("--lookback-ms", type=float, default=8)
    args = parser.parse_args()
    if args.long_msc < 1 or not 0 <= args.lookback_ms <= 100:
        parser.error("expected --long-msc >= 1 and --lookback-ms between 0 and 100")
    try:
        print(json.dumps(report(args.capture, args.long_msc, args.lookback_ms), indent=2, allow_nan=False))
    except (KeyError, OSError, TypeError, ValueError) as error:
        parser.exit(1, f"Capture invalid: {error}\n")


if __name__ == "__main__":
    main()
