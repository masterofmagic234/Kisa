#!/usr/bin/env python3
"""Type a bounded demo command into the verified offline game window."""
import argparse
import ctypes as c
import importlib.util
import os
from pathlib import Path
import re
import runpy
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('pid', type=int)
parser.add_argument('window')
parser.add_argument('command')
console = parser.add_mutually_exclusive_group()
console.add_argument('--console-open', action='store_true')
console.add_argument('--auto-console', action='store_true')
args = parser.parse_args()
demo = 'replays/match730_003852354427767750703_1695226765_421'
kebab_demo = 'replays/match730_003851785353190965676_1755011521_182'
permitted = ('spec_mode 1;spec_player 9', 'quit', 'demo_pause', 'demo_resume',
             'spec_mode 1;spec_player 6', 'demo_pause;demo_gototick 39736',
             'playdemo ' + kebab_demo,
             'cl_demo_predict', 'cl_demo_predict 0;cl_demo_predict',
             'cl_demo_predict 1;cl_demo_predict', 'cl_demo_predict 2;cl_demo_predict',
             'demo_gototick 42500', 'demo_pause;demo_gototick 43100',
             'demo_pause;demo_gototick 10048',
             'fps_max', 'disconnect', 'playdemo ' + demo,
             'vprof_on', 'vprof_off', 'vprof_reset', 'vprof_generate_report',
             'vprof_generate_report_budget', 'vprof_generate_report_hierarchy',
             'help r_strip_invisible_during_sceneobject_update',
             'spec_show_xray 0', 'spec_show_xray 1',
             'cl_draw_only_deathnotices 0;cl_drawhud_force_deathnotices -1',
             'cl_draw_only_deathnotices 1;cl_drawhud_force_deathnotices -1',
             'videocfg_fsr_detail;videocfg_dynamic_shadows;r_player_visibility_mode',
             'cl_draw_only_deathnotices;cl_drawhud_force_deathnotices;cl_teamcounter_playercount_instead_of_avatars;cl_showloadout')
pattern = r'timedemo_start \d+;timedemo_end \d+;timedemo ' + re.escape(demo) + r' cs2-nuke-[a-z0-9-]+\.csv'
assert args.command in permitted or re.fullmatch(pattern, args.command)
assert os.geteuid() != 0 and re.fullmatch(r'0x[0-9a-f]+', args.window)
proc = Path('/proc') / str(args.pid)
start = (proc/'stat').read_text().rsplit(')', 1)[1].split()[19]
active_window = runpy.run_path(str(Path(__file__).with_name('cs2-x11-compositor.py')))['active_window']

def check():
    argv = (proc/'cmdline').read_bytes().split(b'\0')
    assert proc.stat().st_uid == os.getuid() and argv.count(b'-insecure') == 1
    assert b'-secure' not in argv and os.readlink(proc/'exe').endswith('/game/bin/linuxsteamrt64/cs2')
    assert (proc/'stat').read_text().rsplit(')', 1)[1].split()[19] == start
    active = active_window()
    assert active is not None and int(active, 16) == int(args.window, 16), 'CS2 lost focus'
    props = subprocess.check_output(['xprop', '-id', args.window, '_NET_WM_PID', 'WM_CLASS'], text=True)
    assert re.search(r'_NET_WM_PID\(CARDINAL\) = '+str(args.pid)+r'\b', props) and '"cs2"' in props

check()
if args.auto_console:
    from PIL import Image, ImageChops, ImageGrab, ImageStat

    console_bounds = (11, 12, 53, 22)
    console_example = Path(__file__).resolve().parent.parent / 'outputs/cs2-nuke-steam-profile-stock-1793915902/before.png'
    console_title = Image.open(console_example).convert('L').crop(console_bounds)

    def console_is_open():
        current = ImageGrab.grab(bbox=tuple(v * 2 for v in console_bounds)).resize(console_title.size).convert('L')
        return ImageStat.Stat(ImageChops.difference(current, console_title)).mean[0] < 8

spec = importlib.util.spec_from_file_location('existing_xkb', Path(__file__).with_name('cs2-samepid-console.py'))
key = importlib.util.module_from_spec(spec)
spec.loader.exec_module(key)
key.CONTROLS += ('Control_L', 'BackSpace')
x, display, original = key.open_xkb()
xtst = c.CDLL('libXtst.so.6')
xtst.XTestFakeKeyEvent.argtypes = [c.c_void_p, c.c_uint, c.c_int, c.c_ulong]
held = set()

def event(code, down):
    xtst.XTestFakeKeyEvent(display, code, int(down), 0)
    x.XSync(display, 0)
    (held.add if down else held.discard)(code)

try:
    group, mapping, _ = key.discover(x, display, original, args.command + 'a')
    assert x.XkbLockGroup(display, 0x100, group)
    x.XSync(display, 0)

    def tap(name):
        item = mapping[name]
        shift = mapping['Shift_L']['keycode']
        if item['shift']:
            event(shift, True)
        event(item['keycode'], True)
        time.sleep(.08 if name == 'Return' else .012)
        event(item['keycode'], False)
        if item['shift']:
            event(shift, False)
        time.sleep(.008)

    already_open = console_is_open() if args.auto_console else args.console_open
    if not already_open:
        tap('grave')
        time.sleep(.16)
        if args.auto_console:
            deadline = time.monotonic() + 1
            while not console_is_open() and time.monotonic() < deadline:
                check()
                time.sleep(.08)
            assert console_is_open(), 'CS2 console did not open'
    if os.environ.get('CS2_TEST_HFR1_GFX') != '1':
        control = mapping['Control_L']['keycode']
        event(control, True)
        tap('a')
        event(control, False)
        tap('BackSpace')
    for index, char in enumerate(args.command):
        if index % 12 == 0:
            check()
        tap(char)
    check()
    tap('Return')
    if args.command != 'quit':
        time.sleep(.10)
        check()
        if not args.auto_console or console_is_open():
            tap('grave')
finally:
    for code in list(held):
        event(code, False)
    x.XkbLockGroup(display, 0x100, original.locked_group)
    x.XSync(display, 0)
    x.XCloseDisplay(display)
